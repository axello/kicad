# 1w-esp32

2021-01-30  v0.2 - version based on the rs485-esp32-v0.3 version and updated to a sub schematic
                 - Had to replace all components after moving them to the sun schema

# end
